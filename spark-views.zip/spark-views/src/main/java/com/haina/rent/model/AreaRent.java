package com.haina.rent.model;
import lombok.Data;

@Data
public class AreaRent {
    private String district;
    private String address;
    private double area;
    private double areaRent;
}
