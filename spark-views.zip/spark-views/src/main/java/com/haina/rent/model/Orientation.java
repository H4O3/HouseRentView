package com.haina.rent.model;
import lombok.Data;

@Data
public class Orientation {
    private String orientation;
    private double avgRent;
    private int count;
}
