package com.haina.rent.model;
import lombok.Data;

@Data
public class Living {
    private int living;
    private double avgRent;
    private int count;
}
