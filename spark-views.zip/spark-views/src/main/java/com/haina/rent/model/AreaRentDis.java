package com.haina.rent.model;
import lombok.Data;

@Data
public class AreaRentDis {
    private String areaRentDis;
    private double avgRent;
    private int count;
}
