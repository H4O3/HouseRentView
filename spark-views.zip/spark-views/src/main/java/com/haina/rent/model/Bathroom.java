package com.haina.rent.model;

import lombok.Data;

@Data
public class Bathroom {
    private int bathroom;
    private double avgRent;
}
