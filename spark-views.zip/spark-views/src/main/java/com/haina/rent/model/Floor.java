package com.haina.rent.model;

import lombok.Data;

@Data
public class Floor {
    private String floorCount;
    private double avgRent;
}
