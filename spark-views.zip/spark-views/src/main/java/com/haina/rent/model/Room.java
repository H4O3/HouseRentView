package com.haina.rent.model;

import lombok.Data;

@Data
public class Room {
    private String areaDis;
    private double avgRent;
    private double count;
}
