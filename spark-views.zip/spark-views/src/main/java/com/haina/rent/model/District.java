package com.haina.rent.model;

import lombok.Data;

@Data
public class District {
    private String district;
    private double avgRent;
}
